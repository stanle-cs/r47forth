// https://editor.p5js.org/
// Diagram 2: function geometry — theta=50deg (ellipse shape), phi=30deg (amplitude)

function setup() {
  createCanvas(1000, 700);
  noLoop();
}

function draw() {
  background(255);
  translate(240, 310);
  scale(1, -1);

  // ellipse shape fixed by theta=50deg
  let b    = 210;
  let a    = 135;
  let cosT = a/b;
  let sinT = sqrt(1 - cosT*cosT);
  let m    = sinT * sinT;       // 0.58673
  let k    = sinT;              // 0.76599
  let theta = acos(cosT);

  // amplitude phi=30deg — independent of theta
  let sinP = sin(radians(30));  // 0.5
  let cosP = cos(radians(30));  // 0.86603
  let phi  = radians(30);

  // points
  let Px = b * cosT,  Py = b * sinT;    // P on outer circle at theta
  let Qx = b * cosP,  Qy = a * sinP;    // Q on ellipse at phi
  let Rx = Qx,        Ry = 0;           // R foot of vertical from Q
  let EPx = b * cosP, EPy = -(b * sinP);
  let EKx = 0,        EKy = -b;


  // ---- K(m) thick underneath, then F(phi) thinner on top ----
  stroke(0, 70, 180); strokeWeight(8); noFill();
  arc(0, 0, 2*b, 2*b, 0, HALF_PI);

  stroke(100, 180, 255); strokeWeight(4); noFill();
  arc(0, 0, 2*b, 2*b, 0, phi);

  // ---- E(m) thick underneath, then E(phi) thinner on top ----
  stroke(210, 0, 0); strokeWeight(8); noFill();
  beginShape();
  for(let ang = 0; ang <= HALF_PI; ang += 0.01) {
    vertex(b * cos(ang), -(a * sin(ang)));
  }
  vertex(0, -a);
  endShape();

  stroke(255, 100, 180); strokeWeight(4); noFill();
  beginShape();
  for(let ang = 0; ang <= phi; ang += 0.01) {
    vertex(b * cos(ang), -(a * sin(ang)));
  }
  vertex(b * cosP, -(a * sinP));
  endShape();


  // ---- E angle arcs on outer circle bottom ----
  stroke(210, 0, 0); strokeWeight(8); noFill();
  arc(0, 0, 2*b, 2*b, -HALF_PI, 0);
  stroke(255, 100, 180); strokeWeight(4); noFill();
  arc(0, 0, 2*b, 2*b, -phi, 0);

  // ---- base geometry ----
  noFill(); stroke(100, 149, 237); strokeWeight(1.5);
  drawingContext.setLineDash([6, 4]);
  circle(0, 0, 2*b);
  drawingContext.setLineDash([]);

  stroke(50, 180, 130); strokeWeight(1.5);
  drawingContext.setLineDash([6, 4]);
  circle(0, 0, 2*a);
  drawingContext.setLineDash([]);

  stroke(30, 100, 200); strokeWeight(2);
  ellipse(0, 0, 2*b, 2*a);

  stroke(180); strokeWeight(0.8);
  line(-190, 0, 190, 0);
  line(0, -190, 0, 190);

  // OP line (theta)
  stroke(60); strokeWeight(2);
  line(0, 0, Px, Py);

  // dotted vertical from P to axis (shows Px = a)
  stroke(100, 149, 237); strokeWeight(1.2);
  drawingContext.setLineDash([4, 3]);
  line(Px, Py, Px, 0);
  drawingContext.setLineDash([]);

  // OR line (phi)
  stroke(50, 180, 130); strokeWeight(2);
  line(0, 0, Rx, Ry);

  // vertical construction line Q-R
  stroke(200, 80, 60); strokeWeight(1.2);
  drawingContext.setLineDash([5, 4]);
  line(Qx, Qy, Rx, Ry);
  drawingContext.setLineDash([]);

  // right angle mark at R
  stroke(200, 80, 60); strokeWeight(1); noFill();
  let rm = 8;
  beginShape();
  vertex(Rx, Ry + rm);
  vertex(Rx - rm, Ry + rm);
  vertex(Rx - rm, Ry);
  endShape();

  // theta arc at radius 80 (OP)
  stroke(200, 80, 60); strokeWeight(2); noFill();
  arc(0, 0, 80, 80, 0, theta);

  // phi arc at radius 55 (OQ)
  stroke(180, 120, 0); strokeWeight(2); noFill();
  arc(0, 0, 55, 55, 0, phi);

  // sn: vertical segment on left side
  let snX  = -Qx;
  let snQy = a * sinP;
  stroke(220, 50, 220); strokeWeight(5);
  line(snX, 0, snX, snQy);

  // dotted line from Q to sn segment
  stroke(220, 50, 220); strokeWeight(1.2);
  drawingContext.setLineDash([4, 3]);
  line(Qx, Qy, snX, snQy);
  drawingContext.setLineDash([]);

  // cn: horizontal segment O to left
  let cnX = -b * cosP;
  stroke(50, 200, 50); strokeWeight(5);
  line(0, 0, cnX, 0);

  // thin line from O to outer circle at phi (anchors phi arc)
  stroke(180, 120, 0); strokeWeight(1.2);
  drawingContext.setLineDash([3, 3]);
  line(0, 0, b*cosP, b*sinP);
  drawingContext.setLineDash([]);

  // dn: segment O to Q
  stroke(180, 0, 180); strokeWeight(4);
  line(0, 0, Qx, Qy);

  // extend RQ vertical up to outer circle
  let Qext = sqrt(b*b - Qx*Qx);
  stroke(200, 80, 60); strokeWeight(1.2);
  drawingContext.setLineDash([4, 3]);
  line(Qx, Qy, Qx, Qext);
  drawingContext.setLineDash([]);
  noStroke(); fill(0); circle(Qx, Qext, 7);

  // arrowhead helper
  function arrowhead(ax, ay, dx, dy, col, sz) {
    let angle = atan2(dy, dx);
    let x1 = ax + sz * cos(angle + 2.5);
    let y1 = ay + sz * sin(angle + 2.5);
    let x2 = ax + sz * cos(angle - 2.5);
    let y2 = ay + sz * sin(angle - 2.5);
    fill(col[0], col[1], col[2]); noStroke();
    triangle(ax, ay, x1, y1, x2, y2);
  }

  // F arrowhead at phi on outer circle top
  arrowhead(b*cosP, b*sinP, -sinP, cosP, [100, 180, 255], 20);

  // K arrowhead at top of circle
  arrowhead(0, b, -1, 0, [0, 70, 180], 20);

  // E(phi) arrowhead on outer circle bottom
  arrowhead(EPx, EPy, -sinP, -cosP, [255, 100, 180], 20);

  // E(m) arrowhead at bottom of outer circle
  arrowhead(EKx, EKy, -1, 0, [210, 0, 0], 20);

  // E(phi) arrowhead on outer circle bottom


  // ---- all points black ----
  noStroke();
  fill(0); circle(Px,  Py,  9);
  fill(0); circle(Qx,  Qy,  9);
  fill(0); circle(Rx,  Ry,  9);
  fill(0); circle(0,   0,   9);
  fill(0); circle(b*cosP, -(a*sinP), 9);
  fill(0); circle(EPx, EPy, 9);
  fill(0); circle(EKx, EKy, 9);

  // ---- text ----
  scale(1, -1);
  noStroke();
  textFont('monospace');

  // instruction block top left
  textSize(11); textStyle(NORMAL); fill(30);
  text('1. Using [a,b→m] get m',                              -220, -312);
  text('2. From point Q(x,y), get φ = acos(x/b)',            -220, -296);
  text('   or φ = asin(y/a)',                                 -220, -280);
  text('3. Using identity (red), get u = F(φ,m)',             -220, -264);
  text('4. From u & m, get any dimension',                         -220, -248);
  text('   e.g. arc length',                                       -220, -232);
  text('Q is the point on the ellipse',                    -220, -216);
  text('Q(x,y) = (b·cn(u,m), a·sn(u,m))',      -220, -200);

  textSize(14); textStyle(BOLD);
  fill(0);           text('O', -28, 18);
  fill(100,149,237); text('P', (Px-17), (-Py+11));
  fill(30, 100,200); text('Q', (Qx+8), (-Qy-4));
  fill(50, 180,130); text('R', Rx+8, -Ry+13);

  textSize(12); textStyle(NORMAL);
  fill(100,149,237); textAlign(CENTER);
  text('r=b', -b*0.707+2, -b*0.707+12);
  fill(50,180,130);
  text('r=a', -a*0.707+2, -a*0.707+12);
  textAlign(LEFT);

  textSize(11); textStyle(BOLD);

  // theta label at end of theta arc, other side of OP
  fill(200, 80, 60);
  text('\u03b8', 40*cos(theta)+10, -(40*sin(theta))+4);

  // phi label and am at phi arc
  fill(180, 120, 0);
  text('\u03c6 = am(u,m)', (30), (-3));

  // F label
  fill(100, 180, 255);
  text('\u03c6 to F()', b*cosP+9, -b*sinP+2);

  // K label
  fill(0, 70, 180);
  text('\u03c6=\u03c0/2 \u2192 K(\u03c6,m)=K(m)', 0, -(b+12));

  // arc length label at pink dot
  fill(255, 100, 180);
  textSize(10); textStyle(NORMAL);
  text('arc 0\u2192\u03c6', (b*cosP - 102), (-(-(a*sinP)) - 46));
  text('b\u00b7(E(m)\u2212E(\u03c0/2\u2212\u03c6,m))', (b*cosP - 102), (-(-(a*sinP)) - 31));
  textSize(11); textStyle(BOLD);

  // b·E(m) label
  fill(210, 0, 0);
  text('b\u00b7E(m)', (6), (a+14));

  // bottom outer circle labels
  fill(255, 100, 180);
  text('\u03c6 to E()', EPx+9, -EPy+6);
  fill(210, 0, 0);
  text('\u03c6=\u03c0/2 \u2192 b\u00b7E(\u03c6,m)=b\u00b7E(m)', 0, b+17);

  // reflection point labels
  textSize(14); textStyle(BOLD);
  fill(0); text("R'", cnX-22, 16);
  fill(0); text("O'", cnX-22, -snQy-6);
  textSize(11); textStyle(BOLD);

  // E arc labels removed — restored below

  fill(210, 0, 0);

  // sn, cn, dn
  fill(220, 50, 220);
  text('a\u00b7sn(u,m)', (cnX+11), (-snQy+14));  // = height of Q = Qy

  fill(50, 200, 50);
  text('b\u00b7cn(u,m)', (cnX+6), (14));  // = horiz reach = Qx

  fill(180, 0, 180);
  text('b\u00b7dn(u,m)', (Qx/2+14), (-Qy/2+5));

  // right panel legend
  let rx = 250, ry = -255, ls = 19;
  textSize(12); textStyle(NORMAL);

  fill(30); textStyle(BOLD);
  text('Function geometry:', (rx), (ry)); textStyle(NORMAL);
  ry += ls + 2;

  function swatch(r,g,b2, label, desc) {
    fill(r,g,b2); rect(rx, ry-10, 10, 10);
    fill(30);
    let padded = (label + '          ').substring(0, 10);
    text(padded + ': ' + desc, rx+14, ry);
    ry += ls;
  }

  swatch(100,180,255, 'F(\u03c6,m)',   'swept \u03c6 shown, input to F integral');
  swatch(0,70,180,    'K(m)',          '\u03c0/2 or \u00bc period, input to F integral');
  swatch(255,100,180, 'arc 0\u2192\u03c6', 'b\u00b7(E(m)\u2212E(\u03c0/2\u2212\u03c6,m))');
  swatch(210,0,0,     'b\u00b7E(m)',   'quarter ellipse arc length');
  swatch(220,50,220,  'a\u00b7sn(u,m)', 'height of Q = Qy');
  swatch(50,200,50,   'b\u00b7cn(u,m)', 'horizontal reach of R = Qx');
  swatch(180,0,180,   'b\u00b7dn(u,m)', 'distance O to Q');
  swatch(200,80,60,   'am(u,m)',       'amplitude angle \u03c6, or angle to Q');
  swatch(180,120,0,   '\u03c6',        'amplitude = 30\u00b0');
  swatch(200,80,60,   '\u03b8',        'eccentricity angle = 50\u00b0');

  ry += 2;
  fill(30); textStyle(ITALIC);
  text('\u2192 outer circle arcs: \u03c6 input to F, K, E', (rx), (ry)); ry += ls;
  textStyle(NORMAL);
  text('Z(\u03c6,m) = E(\u03c6,m) \u2212 (E(m)/K(m))\u00b7F(\u03c6,m)', (rx), (ry)); ry += ls;
  text('\u03a0(n,m) : no direct geometric form', (rx), (ry)); ry += ls + 4;

  fill(60); textStyle(NORMAL);
  text('a,b: ellipse semi-axes  m=1-(a/b)\u00b2', (rx), (ry)); ry += ls;
  text('k=\u221am  \u03b8=arcsin(k)  \u03c6=amplitude', (rx), (ry));

  // red identity block
  let ibx = 250, iby = 225;
  textSize(11); textStyle(BOLD);
  fill(200, 0, 0);
  text('u = F(\u03c6, m)', (ibx), (iby));
  text('\u03c6 = am(u, m)', (ibx), (iby+16));
  text('F(\u03c6, m) = am\u207b\u00b9(\u03c6, m)', (ibx), (iby+32));
  textStyle(NORMAL);

  // dotted red arrow
  scale(1, -1);
  stroke(200, 0, 0); strokeWeight(1.5);
  drawingContext.setLineDash([4, 3]);
  let ax1 = (ibx - 5), ay1 = (-iby + 13);
  let ax2 = 98,            ay2 = 1;
  line(ax1, ay1, ax2, ay2);
  drawingContext.setLineDash([]);
  let aang = atan2(ay2 - ay1, ax2 - ax1);
  fill(200, 0, 0); noStroke();
  triangle(ax2, ay2,
           ax2 + 10*cos(aang + 2.5), ay2 + 10*sin(aang + 2.5),
           ax2 + 10*cos(aang - 2.5), ay2 + 10*sin(aang - 2.5));
  scale(1, -1);

  // legend bottom left
  let lx = -225, ly = 240, lg = 18;
  textSize(11); textStyle(NORMAL);
  fill(100,149,237); rect(lx, ly,      11, 11); fill(30); text('outer circle  r = b', (lx+15), (ly+9));
  fill(50, 180,130); rect(lx, ly+lg,   11, 11); fill(30); text('inner circle  r = a', (lx+15), (ly+lg+9));
  fill(30, 100,200); rect(lx, ly+2*lg, 11, 11); fill(30); text('ellipse  (semi-axes a, b)', (lx+15), (ly+2*lg+9));
}
