// https://editor.p5js.org/
// Diagram 1: ellipse geometry, eccentricity angle theta, amplitude angle phi
// Slider 1 (top): theta — defines ellipse shape (a, m, k)
// Slider 2 (below): phi  — independent amplitude angle

let tTheta, tPhi;

function setup() {
  createCanvas(900, 600);
  tTheta = createSlider(1, 89, 50, 1);
  tTheta.position(20, 555);
  tTheta.style('width', '180px');
  tPhi = createSlider(1, 89, 30, 1);
  tPhi.position(240, 555);
  tPhi.style('width', '180px');
}

function draw() {
  background(255);
  translate(240, 270);
  scale(1, -1);

  let b     = 150;
  let theta = radians(tTheta.value());
  let phi   = radians(tPhi.value());
  let sinT  = sin(theta);
  let cosT  = cos(theta);
  let a     = b * cosT;
  let m     = sinT * sinT;
  let k     = sinT;

  // eccentricity construction points (theta)
  let Px = b * cosT, Py = b * sinT;
  let Rx = Px,       Ry = 0;

  // amplitude point Q on ellipse at phi (independent)
  let Qx = b * cos(phi), Qy = a * sin(phi);
  let Rqx = Qx,          Rqy = 0;
  // P_phi: point on outer circle at phi (anchors phi arc)
  let PPx = b * cos(phi), PPy = b * sin(phi);

  // outer circle
  noFill(); stroke(100, 149, 237); strokeWeight(1.5);
  drawingContext.setLineDash([6, 4]);
  circle(0, 0, 2*b);
  drawingContext.setLineDash([]);

  // inner circle
  stroke(50, 180, 130); strokeWeight(1.5);
  drawingContext.setLineDash([6, 4]);
  circle(0, 0, 2*a);
  drawingContext.setLineDash([]);

  // ellipse
  stroke(30, 100, 200); strokeWeight(2);
  ellipse(0, 0, 2*b, 2*a);

  // axes
  stroke(180); strokeWeight(0.8);
  line(-190, 0, 190, 0);
  line(0, -190, 0, 190);

  // OP line (theta — eccentricity)
  stroke(60); strokeWeight(2);
  line(0, 0, Px, Py);

  // OR line (a on major axis)
  stroke(50, 180, 130); strokeWeight(2);
  line(0, 0, Rx, Ry);

  // vertical construction line P to axis
  stroke(0); strokeWeight(1.2);
  drawingContext.setLineDash([5, 4]);
  line(Px, Py, Rx, Ry);
  drawingContext.setLineDash([]);

  // right angle mark at R
  stroke(0); strokeWeight(1); noFill();
  let rm = 8;
  beginShape();
  vertex(Rx, Ry + rm); vertex(Rx - rm, Ry + rm); vertex(Rx - rm, Ry);
  endShape();

  // thin dashed line O to outer circle at phi (anchors phi arc)
  stroke(200, 0, 0); strokeWeight(1.2);
  drawingContext.setLineDash([3, 3]);
  line(0, 0, PPx, PPy);
  drawingContext.setLineDash([]);

  // OQ line (phi — amplitude, red)
  stroke(200, 0, 0); strokeWeight(2);
  line(0, 0, Qx, Qy);

  // vertical construction line Q to axis (dotted orange)
  stroke(200, 0, 0); strokeWeight(1.2);
  drawingContext.setLineDash([5, 4]);
  line(Qx, Qy, Rqx, Rqy);
  drawingContext.setLineDash([]);

  // right angle mark at Rq
  stroke(200, 0, 0); strokeWeight(1); noFill();
  beginShape();
  vertex(Rqx, Rqy + rm); vertex(Rqx - rm, Rqy + rm); vertex(Rqx - rm, Rqy);
  endShape();

  // theta arc (red, radius 70)
  stroke(0); strokeWeight(1); noFill();
  arc(0, 0, 90, 90, 0, theta);

  // phi arc (orange, radius 50)
  stroke(200, 0, 0); strokeWeight(1); noFill();
  arc(0, 0, 50, 50, 0, phi);

  // points — all black
  noStroke();
  fill(0); circle(Px, Py, 9);
  fill(0); circle(Qx, Qy, 9);
  fill(0); circle(Rx, Ry, 9);
  fill(0); circle(Rqx, Rqy, 9);
  fill(0); circle(0,  0,  9);
  // no dot at PPhi

  // flip for text
  scale(1, -1);
  noStroke();
  textFont('monospace');

  textSize(14); textStyle(BOLD);
  fill(0);           text('O',  -18, 18);
  fill(100,149,237); text('P',  Px+8,  -Py-4);
  fill(30, 100,200); text('Q',  Qx+8,  -Qy-4);
  fill(50, 180,130); text('R',  Rx+8,  -Ry+18);
  fill(180,120,0);   text('Rq', Rqx+4, -Rqy+18);

  textSize(12); textStyle(NORMAL);
  // b label: left of outer circle, just above axis
  fill(100,149,237); text('r=b', -b-32, -10);
  // a label: left of inner circle, just above axis
  fill(50, 180,130);  text('r=a', -a-32, -10);
  // theta: centred at x=45, below axis
  fill(0);
  textAlign(CENTER);
  text('\u03b8', 45, 14);
  // phi: centred at x=25, below axis
  fill(200, 0, 0);
  text('\u03c6', 25, 14);
  textAlign(LEFT);

  // right panel
  let rx = 195, ry = -255, ls = 19;
  textSize(12); textStyle(NORMAL);

  fill(30); textStyle(BOLD); text('Variables (calculator):', rx, ry); textStyle(NORMAL);
  ry += ls + 2;

  fill(180,60,60);
  text('m = sin\u00b2\u03b8     = 1-(a/b)\u00b2 = ' + m.toFixed(4), rx, ry); ry += ls;
  text('k = sin\u03b8      = \u221am       = ' + k.toFixed(4),      rx, ry); ry += ls;
  text('e = k         = sin\u03b8     = ' + k.toFixed(4),           rx, ry); ry += ls;
  text('\u03b8 = arcsin(k) = arcsin(\u221am)',                        rx, ry); ry += ls + 6;

  fill(30); textStyle(BOLD); text('Conversions:', rx, ry); textStyle(NORMAL);
  ry += ls;
  fill(100,100,180);
  text('m \u2192 k   : k = \u221am',                    rx, ry); ry += ls;
  text('k \u2192 m   : m = k\u00b2',                    rx, ry); ry += ls;
  text('m \u2192 \u03b8   : \u03b8 = arcsin(\u221am)',  rx, ry); ry += ls;
  text('\u03b8 \u2192 m   : m = sin\u00b2(\u03b8)',      rx, ry); ry += ls;
  text('a,b \u2192 m : m = 1-(min/max)\u00b2',           rx, ry); ry += ls;
  text('            (a,b swapped if a > b)',             rx, ry); ry += ls + 6;

  fill(30); textStyle(BOLD); text('Function arguments:', rx, ry); textStyle(NORMAL);
  ry += ls;
  fill(80,130,80);
  text('sn(u,m)  cn(u,m)  dn(u,m)',               rx, ry); ry += ls;
  text('am(u,m)  K(m)     E(m)',                   rx, ry); ry += ls;
  text('F(\u03c6,m)   E(\u03c6,m)   Z(\u03c6,m)', rx, ry); ry += ls;
  text('\u03a0(n,m)',                               rx, ry); ry += ls + 6;

  fill(30);
  text('\u03c6 : amplitude angle (any angle mode)', rx, ry); ry += ls;
  text('u : real number (not an angle)',            rx, ry);

  // legend bottom left
  let lx = -225, ly = 185, lg = 18;
  textSize(11);
  fill(100,149,237); rect(lx, ly,      11, 11); fill(30); text('outer circle  r = b',       lx+15, ly+9);
  fill(50, 180,130); rect(lx, ly+lg,   11, 11); fill(30); text('inner circle  r = a',       lx+15, ly+lg+9);
  fill(30, 100,200); rect(lx, ly+2*lg, 11, 11); fill(30); text('ellipse  (semi-axes a, b)', lx+15, ly+2*lg+9);

  // slider readouts
  fill(0); textSize(11);
  text('\u03b8 = ' + tTheta.value() + '\u00b0  k = ' + k.toFixed(4) + '  m = ' + m.toFixed(4), -225, 262);
  fill(200, 0, 0);
  text('\u03c6 = ' + tPhi.value() + '\u00b0  (amplitude — independent of \u03b8)', -225, 276);
}
