// https://editor.p5js.org/
// Diagram 4: numerical verification
// a=100, b=300, theta=70.529deg, phi=23deg
// Note: Px = b*cos(theta) = a = 100 exactly
// Verify: m=0.88889, k=0.94281, phi=0.40143 rad

function setup() {
  createCanvas(1100, 760);
  noLoop();
}

function draw() {
  background(255);
  translate(340, 390);
  scale(1, -1);

  let b    = 300;
  let a    = 100;
  let cosT = a/b;
  let sinT = sqrt(1 - cosT*cosT);
  let m    = sinT*sinT;
  let k    = sinT;

  let sinP = sin(radians(23));
  let cosP = cos(radians(23));
  let phi  = radians(23);
  let theta = acos(cosT);

  let Px = b*cosT, Py = b*sinT;     // Px = a = 100 exactly
  let Qx = b*cosP, Qy = a*sinP;
  let Rx = Qx,     Ry = 0;
  let EPx = b*cosP, EPy = -(b*sinP);
  let EKx = 0,      EKy = -b;
  let snX  = -Qx;
  let snQy = a*sinP;
  let cnX  = -b*cosP;

  // K(m) thick, F(phi) thin on top
  stroke(0,70,180); strokeWeight(8); noFill();
  arc(0,0,2*b,2*b,0,HALF_PI);
  stroke(100,180,255); strokeWeight(4); noFill();
  arc(0,0,2*b,2*b,0,phi);

  // E(m) thick, E(phi) thin on top
  stroke(210,0,0); strokeWeight(8); noFill();
  beginShape();
  for(let ang=0; ang<=HALF_PI; ang+=0.01) { vertex(b*cos(ang),-(a*sin(ang))); }
  vertex(0,-a); endShape();
  stroke(255,100,180); strokeWeight(4); noFill();
  beginShape();
  for(let ang=0; ang<=phi; ang+=0.01) { vertex(b*cos(ang),-(a*sin(ang))); }
  vertex(b*cosP,-(a*sinP)); endShape();

  // E angle arcs on outer circle bottom
  stroke(210,0,0); strokeWeight(8); noFill();
  arc(0,0,2*b,2*b,-HALF_PI,0);
  stroke(255,100,180); strokeWeight(4); noFill();
  arc(0,0,2*b,2*b,-phi,0);

  // E angle arcs on outer circle bottom
  stroke(210, 0, 0); strokeWeight(8); noFill();
  arc(0, 0, 2*b, 2*b, -HALF_PI, 0);
  stroke(255, 100, 180); strokeWeight(4); noFill();
  arc(0, 0, 2*b, 2*b, -phi, 0);

  // base geometry
  noFill(); stroke(100,149,237); strokeWeight(1.5);
  drawingContext.setLineDash([6,4]); circle(0,0,2*b); drawingContext.setLineDash([]);
  stroke(50,180,130); strokeWeight(1.5);
  drawingContext.setLineDash([6,4]); circle(0,0,2*a); drawingContext.setLineDash([]);
  stroke(30,100,200); strokeWeight(2); ellipse(0,0,2*b,2*a);
  stroke(180); strokeWeight(0.8);
  line(-320,0,320,0); line(0,-320,0,320);

  stroke(60); strokeWeight(2); line(0,0,Px,Py);
  stroke(100,149,237); strokeWeight(1.2);
  drawingContext.setLineDash([4,3]); line(Px,Py,Px,0); drawingContext.setLineDash([]);
  stroke(50,180,130); strokeWeight(2); line(0,0,Rx,Ry);
  stroke(200,80,60); strokeWeight(1.2);
  drawingContext.setLineDash([5,4]); line(Qx,Qy,Rx,Ry); drawingContext.setLineDash([]);

  stroke(200,80,60); strokeWeight(1); noFill();
  let rm = 8;
  beginShape(); vertex(Rx,Ry+rm); vertex(Rx-rm,Ry+rm); vertex(Rx-rm,Ry); endShape();

  // angle arcs — strokeWeight(2)
  stroke(200,80,60); strokeWeight(2); noFill(); arc(0,0,80,80,0,theta);
  stroke(180,120,0); strokeWeight(2); noFill(); arc(0,0,55,55,0,phi);

  stroke(220,50,220); strokeWeight(5); line(snX,0,snX,snQy);
  stroke(220,50,220); strokeWeight(1.2);
  drawingContext.setLineDash([4,3]); line(Qx,Qy,snX,snQy); drawingContext.setLineDash([]);
  stroke(50,200,50); strokeWeight(5); line(0,0,cnX,0);
  stroke(180,120,0); strokeWeight(1.2);
  drawingContext.setLineDash([3,3]); line(0,0,b*cosP,b*sinP); drawingContext.setLineDash([]);
  stroke(180,0,180); strokeWeight(4); line(0,0,Qx,Qy);

  // extend RQ vertical up to outer circle
  let Qext = sqrt(b*b - Qx*Qx);
  stroke(200, 80, 60); strokeWeight(1.2);
  drawingContext.setLineDash([4, 3]);
  line(Qx, Qy, Qx, Qext);
  drawingContext.setLineDash([]);
  noStroke(); fill(0); circle(Qx, Qext, 7);

  function arrowhead(ax,ay,dx,dy,col,sz) {
    let angle = atan2(dy,dx);
    fill(col[0],col[1],col[2]); noStroke();
    triangle(ax,ay, ax+sz*cos(angle+2.5),ay+sz*sin(angle+2.5),
                    ax+sz*cos(angle-2.5),ay+sz*sin(angle-2.5));
  }
  arrowhead(b*cosP,b*sinP,-sinP,cosP,[100,180,255],20);
  arrowhead(0,b,-1,0,[0,70,180],20);
  arrowhead(EPx,EPy,-sinP,-cosP,[255,100,180],20);
  arrowhead(EKx,EKy,-1,0,[210,0,0],20);

  noStroke();
  fill(0); circle(Px,Py,9); circle(Qx,Qy,9); circle(Rx,Ry,9); circle(0,0,9);
  fill(0); circle(b*cosP,-(a*sinP),9);
  fill(0); circle(EPx,EPy,9);
  fill(0); circle(EKx,EKy,9); circle(EPx,EPy,9); circle(EKx,EKy,9);

  // ---- text ----
  scale(1,-1);
  noStroke(); textFont('monospace');

  // top left instruction block
  textSize(11); textStyle(NORMAL); fill(30);
  text('1. Using [a,b→m] get m',                              -320, -330);
  text('2. From point Q(x,y), get φ = acos(x/b)',            -320, -314);
  text('   or φ = asin(y/a)',                                 -320, -298);
  text('3. Using identity (red), get u = F(φ,m)',             -320, -282);
  text('4. From u & m, get any dimension',                         -320, -266);
  text('   e.g. arc length',                                       -320, -250);
  text('Q is the point on the ellipse',                    -320, -234);
  text('Q(x,y) = (b\u00b7cn(u,m), a\u00b7sn(u,m))',      -320, -218);

  textSize(14); textStyle(BOLD);
  fill(0);           text('O',  -28, 18);
  fill(100,149,237); text('P',  Px-17, -Py+11);
  fill(30,100,200);  text('Q',  Qx+8,  -Qy-4);
  fill(50,180,130);  text('R',  Rx+8,  -Ry+13);
  fill(0);           text("R'", cnX-22, 16);
  fill(0);           text("O'", cnX-22, -snQy-6);

  textSize(12); textStyle(NORMAL);
  // circle labels at 135deg inside outer circle
  fill(100,149,237); textAlign(CENTER);
  text('r=b=300', -b*0.707+2, -b*0.707+12);
  fill(50,180,130);
  text('r=a=100', -a*0.707+2, -a*0.707+12);
  textAlign(LEFT);

  textSize(11); textStyle(BOLD);

  // theta label rotated along OP
  fill(200,80,60);
  push();
  translate(40*cos(theta)+10, -(40*sin(theta))+4);
  rotate(-theta);
  text('\u03b8=70.529\u00b0', 0, 0);
  pop();

  fill(180,120,0);
  push();
  translate(45, -23);
  rotate(radians(-23));
  text('\u03c6=am(u,m)=23\u00b0', 0, 12);
  pop();

  fill(100,180,255);
  text('\u03c6=0.40143', b*cosP+9, -b*sinP+2);
  text('  to F()', b*cosP+9, -b*sinP+14);

  fill(0,70,180);
  text('\u03c6=\u03c0/2 \u2192 K(\u03c6,m) = K(m) = 2.5286', 0, -(b+12));

  fill(255,100,180);
  textSize(11); textStyle(BOLD);
  text('arc 0\u2192\u03c6 = 47.385', b*cosP-107, -(-(a*sinP))-14);

  fill(210,0,0);
  text('b\u00b7E(m)=334.12', 6, a+14);

  fill(255,100,180);
  text('\u03c6=0.40143 to E()', EPx+9, -EPy+6);

  fill(210,0,0);
  fill(255, 100, 180);
  fill(210, 0, 0);
  text('\u03c6=\u03c0/2 \u2192 b\u00b7E(\u03c6,m)=b\u00b7E(m)=334.12', 0, b+17);

  fill(220,50,220);
  text('Qy=a\u00b7sn=39.073', cnX+11, -snQy+14);

  fill(50,200,50);
  text('Qx=b\u00b7cn=276.15', cnX+6, 14);

  fill(180,0,180);
  text('b\u00b7dn=278.90', Qx/2+14, -Qy/2+10);

  // right panel
  let rx = 285, ry = -367, ls = 19;
  textSize(12); textStyle(NORMAL);
  fill(30); textStyle(BOLD);
  text('Values: \u03b8\u224870.529\u00b0 \u03c6=23\u00b0 b=300', rx, ry); textStyle(NORMAL);
  ry += ls+2;

  function swatch(r,g,b2,label,val) {
    fill(r,g,b2); rect(rx,ry-10,10,10);
    fill(30);
    let padded = (label+'          ').substring(0,10);
    text(padded+': '+val, rx+14, ry);
    ry += ls;
  }

  swatch(100,180,255, 'F(\u03c6,m)',        '0.41133');
  swatch(0,70,180,    'K(m)',               '2.5286');
  swatch(255,100,180, 'arc 0\u2192\u03c6',  '47.385');
  swatch(210,0,0,     'b\u00b7E(m)',        '334.12');
  swatch(220,50,220,  'a\u00b7sn(u,m)',      '39.073');
  swatch(50,200,50,   'b\u00b7cn(u,m)',      '276.15');
  swatch(180,0,180,   'b\u00b7dn(u,m)',      '278.90');
  swatch(200,80,60,   'am(u,m)',            '0.40143 rad');
  ry += 4;
  fill(30);
  text('m=0.88889  k=0.94281', rx, ry); ry += ls;
  text('a=100      b=300',     rx, ry); ry += ls;
  text('\u03c6=23\u00b0=0.40143 rad  \u03b8\u224870.529\u00b0', rx, ry); ry += ls;
  fill(100,100,100); textStyle(ITALIC);
  text('Note: Px = b\u00b7cos\u03b8 = a = 100', rx, ry); textStyle(NORMAL);
  ry += ls+4;

  // red identity block
  let ibx = 285, iby = 273;
  textSize(11); textStyle(BOLD); fill(200,0,0);
  text('u = F(\u03c6, m) = 0.41133',               ibx, iby);
  text('\u03c6 = am(u, m) = 0.40143',              ibx, iby+16);
  text('F(\u03c6, m) = am\u207b\u00b9(\u03c6, m)', ibx, iby+32);
  textStyle(NORMAL);

  scale(1,-1);
  stroke(200,0,0); strokeWeight(1.5);
  drawingContext.setLineDash([4,3]);
  let ax1 = ibx-5, ay1 = -iby+13;
  let ax2 = 65,    ay2 = 12;
  line(ax1,ay1,ax2,ay2);
  drawingContext.setLineDash([]);
  let aang = atan2(ay2-ay1,ax2-ax1);
  fill(200,0,0); noStroke();
  triangle(ax2,ay2,
           ax2+10*cos(aang+2.5),ay2+10*sin(aang+2.5),
           ax2+10*cos(aang-2.5),ay2+10*sin(aang-2.5));
  scale(1,-1);

  // bottom left legend
  let lx = -320, ly = 273, lg = 18;
  textSize(11); textStyle(NORMAL);
  fill(100,149,237); rect(lx,ly,     11,11); fill(30); text('outer circle  r = b = 300',    lx+15,ly+9);
  fill(50,180,130);  rect(lx,ly+lg,  11,11); fill(30); text('inner circle  r = a = 100',    lx+15,ly+lg+9);
  fill(30,100,200);  rect(lx,ly+2*lg,11,11); fill(30); text('ellipse  (b=300, a=100)',       lx+15,ly+2*lg+9);
}
