// https://editor.p5js.org/
// ------------------------


let t;

function setup() {
  createCanvas(900, 580);
  t = createSlider(1, 89, 50, 1);
  t.position(20, 540);
  t.style('width', '200px');
}

function draw() {
  background(255);
  translate(240, 270);
  scale(1, -1);

  // derive everything from theta
  let b     = 150;
  let theta = radians(t.value());
  let sinT  = sin(theta);
  let cosT  = cos(theta);
  let a     = b * cosT;        // a = b*cos(θ)
  let m     = sinT * sinT;     // m = sin²(θ)  exact
  let k     = sinT;            // k = sin(θ)   exact

  let Px = b * cosT, Py = b * sinT;
  let Qx = Px,       Qy = a * sinT;
  let Rx = Px,       Ry = 0;

  // outer circle
  noFill(); stroke(100, 149, 237); strokeWeight(1.5);
  circle(0, 0, 2*b);

  // inner circle
  stroke(50, 180, 130); strokeWeight(1.5);
  circle(0, 0, 2*a);

  // ellipse
  stroke(30, 100, 200); strokeWeight(2);
  ellipse(0, 0, 2*b, 2*a);

  // axes
  stroke(180); strokeWeight(0.8);
  line(-190, 0, 190, 0);
  line(0, -190, 0, 190);

  // OP
  stroke(60); strokeWeight(2);
  line(0, 0, Px, Py);

  // OR (along major axis)
  stroke(50, 180, 130); strokeWeight(2);
  line(0, 0, Rx, Ry);

  // vertical construction line P-Q-R
  stroke(200, 80, 60); strokeWeight(1.2);
  drawingContext.setLineDash([5, 4]);
  line(Px, Py, Rx, Ry);
  drawingContext.setLineDash([]);

  // right angle mark at R
  stroke(200, 80, 60); strokeWeight(1); noFill();
  let rm = 8;
  beginShape();
  vertex(Rx, Ry + rm);
  vertex(Rx - rm, Ry + rm);
  vertex(Rx - rm, Ry);
  endShape();

  // angle arc
  stroke(200, 80, 60); strokeWeight(2); noFill();
  arc(0, 0, 70, 70, 0, theta);

  // points — all black
  noStroke();
  fill(0); circle(Px, Py, 9);
  fill(0); circle(Qx, Qy, 9);
  fill(0); circle(Rx, Ry, 9);
  fill(0); circle(0,  0,  9);

  // flip for text
  scale(1, -1);
  noStroke();
  textFont('monospace');

  // point labels
  textSize(14); textStyle(BOLD);
  fill(0);           text('O', -18, 18);
  fill(100,149,237); text('P', Px+8,  -Py-4);
  fill(30, 100,200); text('Q', Qx+8,  -Qy-4);
  fill(50, 180,130); text('R', Rx+8,  -Ry+18);

  // dimension labels
  textSize(12); textStyle(NORMAL);
  fill(100,149,237); text('b', Px/2-14, -Py/2-2);
  fill(50, 180,130); text('a', Rx/2-4,  14);
  fill(200,80, 60);  text('\u03b8', 40, -8);

  // right panel
  let rx = 195, ry = -255, ls = 19;
  textSize(12); textStyle(NORMAL);

  fill(30); textStyle(BOLD); text('Variables (calculator):', rx, ry); textStyle(NORMAL);
  ry += ls + 2;

  // variables: four extra spaces before second "="
  fill(180,60,60);
  text('m = sin\u00b2\u03b8     = 1-(a/b)\u00b2 = ' + m.toFixed(4), rx, ry); ry += ls;
  text('k = sin\u03b8      = \u221am       = ' + k.toFixed(4),      rx, ry); ry += ls;
  text('e = k         = sin\u03b8     = ' + k.toFixed(4),          rx, ry); ry += ls;
  text('\u03b8 = arcsin(k) = arcsin(\u221am)',                        rx, ry); ry += ls + 6;

  fill(30); textStyle(BOLD); text('Conversions:', rx, ry); textStyle(NORMAL);
  ry += ls;
  fill(100,100,180);
  // two extra spaces before each ":" in first four lines
  text('m \u2192 k   : k = \u221am',                               rx, ry); ry += ls;
  text('k \u2192 m   : m = k\u00b2',                               rx, ry); ry += ls;
  text('m \u2192 \u03b8   : \u03b8 = arcsin(\u221am)',             rx, ry); ry += ls;
  text('\u03b8 \u2192 m   : m = sin\u00b2(\u03b8)',                rx, ry); ry += ls;
  text('a,b \u2192 m : m = 1-(min/max)\u00b2',                      rx, ry); ry += ls;
  text('            (a,b swapped if a > b)',                       rx, ry); ry += ls + 6;

  fill(30); textStyle(BOLD); text('Function arguments:', rx, ry); textStyle(NORMAL);
  ry += ls;
  fill(80,130,80);
  text('sn(u,m)  cn(u,m)  dn(u,m)',               rx, ry); ry += ls;
  text('am(u,m)  K(m)     E(m)',                   rx, ry); ry += ls;
  text('F(\u03c6,m)   E(\u03c6,m)   Z(\u03c6,m)', rx, ry); ry += ls;
  text('\u03a0(n,m)',                               rx, ry); ry += ls + 6;

  fill(30);
  text('\u03c6 : amplitude angle (any angle mode)', rx, ry); ry += ls;
  text('u : real number (not an angle)',            rx, ry); ry += ls;
  fill(120); textStyle(ITALIC);
  text('OR = a only when \u03c6 = \u03b8',           rx, ry);
  textStyle(NORMAL);

  // legend bottom left
  let lx = -225, ly = 185, lg = 18;
  textSize(11);
  fill(100,149,237); rect(lx, ly,      11, 11); fill(30); text('outer circle  r = b',       lx+15, ly+9);
  fill(50, 180,130); rect(lx, ly+lg,   11, 11); fill(30); text('inner circle  r = a',       lx+15, ly+lg+9);
  fill(30, 100,200); rect(lx, ly+2*lg, 11, 11); fill(30); text('ellipse  (semi-axes a, b)', lx+15, ly+2*lg+9);

  // slider readout
  fill(0); textSize(12);
  text('\u03b8 = ' + t.value() + '\u00b0     k = ' + k.toFixed(4) + '     m = ' + m.toFixed(4), -225, 258);
}
